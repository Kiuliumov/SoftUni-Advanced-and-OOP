import unittest
from project.tennis_player import TennisPlayer


class TestTennisPlayer(unittest.TestCase):
    def setUp(self) -> None:
        self.tennis_player = TennisPlayer(name='Ivan', age=19, points=500)

    def test_instantiation(self):
        tennis_player = TennisPlayer(name='Ivan', age=19, points=500)
        self.assertEqual(tennis_player.name, 'Ivan')
        self.assertEqual(tennis_player.age, 19)
        self.assertEqual(tennis_player.points, 500)
        self.assertEqual(tennis_player.wins, [])

    def test_name_setter_pass(self):
        tennis_player = TennisPlayer(name='Ivan', age=19, points=500)
        tennis_player.name = 'Ivan1'
        self.assertEqual(self.tennis_player.name, 'Ivan1')

    def test_name_setter_fail_if_less_than_2(self):
        with self.assertRaises(ValueError) as e:
            tennis_player = TennisPlayer(name='I', age=19, points=500)
            self.assertEqual('Name should be more than 2 symbols!', str(e.exception))

    def test_name_setter_fail_if_equals_2(self):

        with self.assertRaises(ValueError) as e:
            tennis_player = TennisPlayer(name='Iv', age=19, points=500)
            self.assertEqual('Name should be more than 2 symbols!', str(e.exception))

    def test_age_setter_pass(self):
        tennis_player = TennisPlayer(name='Ivan', age=19, points=500)
        tennis_player.age = 21
        self.assertEqual(tennis_player.age, 21)

    def test_age_setter_fail(self):
        with self.assertRaises(ValueError) as e:
            tennis_player = TennisPlayer(name='Ivan', age=15, points=500)
            self.assertEqual('Players must be at least 18 years of age!', str(e.exception))

    def test_points_setter_pass(self):
        tennis_player = TennisPlayer(name='Ivan', age=19, points=500)
        tennis_player.points = 600
        self.assertEqual(tennis_player.points, 600)

    
    def test_add_new_wins_method_when_adding_a_valid_win(self):
        tennis_player = TennisPlayer(name='Ivan', age=19, points=500)
        tennis_player.add_new_win('TestTournament')
        self.assertEqual(tennis_player.wins, ['TestTournament'])

    def test_add_new_wins_method_when_adding_an_already_added_tournament(self):
        tennis_player = TennisPlayer(name='Ivan', age=19, points=500)
        tennis_player.add_new_win('TestTournament')
        self.assertEqual('TestTournament has been already added to the list of wins!',
                         tennis_player.add_new_win('TestTournament'))
    def test_less_than_when_player_has_more_points(self):
        tennis_player = TennisPlayer(name='Ivan', age=19, points=500)
        tennis_player_1 = TennisPlayer(name='Ivana', age=19, points=501)

        self.assertEqual('Ivana is a top seeded player and he/she is better than Ivan', tennis_player < tennis_player_1)

    def test_less_than_when_player_has_less_points(self):
        tennis_player = TennisPlayer(name='Ivan', age=19, points=500)
        tennis_player_1 = TennisPlayer(name='Ivana', age=19, points=499)

        self.assertEqual('Ivan is a better player than Ivana', tennis_player < tennis_player_1)

    def test_string_method(self):
        tennis_player = TennisPlayer(name='Ivan', age=19, points=500)

        tennis_player.add_new_win('TestTournament')
        tennis_player.add_new_win('TestTournament1')
        tennis_player.add_new_win('TestTournament2')
        tennis_player.add_new_win('TestTournament3')
        tennis_player.add_new_win('TestTournament4')

        str_player = tennis_player.__str__()

        compare_str = f"Tennis Player: Ivan\n" \
                      f"Age: 19\n" \
                      f"Points: 500.0\n" \
                      f"Tournaments won: TestTournament, TestTournament1, TestTournament2, TestTournament3, TestTournament4"

        self.assertEqual(str_player, compare_str)


if __name__ == '__main__':
    unittest.main()
